# Changelog

These are **processing stages**, not evidence of historically published software versions.

## 0.1.0 — Repository assembly (pre-release)
- Collected nine uploaded source scripts. Preserved exact originals in `archive/original_sources/`.
- Introduced cross-platform paths via environment variables; did not alter formulae.
- Set the corrected NTL candidate as the default product used by validation and NPP scripts.
- Added a dispatcher, preflight inventory, integrity manifest and documentation.

## Provenance: historical scientific workflow (unreleased stages)
- **Initial workflow:** `recalculate_ERI_2001_2020_FINAL.py` generated five indicators and legacy ERI products.
- **Source audit:** the PANDA-China `-32768` undeclared fill was investigated with matched full-grid reprojections.
- **Corrected candidate:** regenerated NTL, HCI, fixed pooled entropy weights and 20 annual ERPI rasters while preserving legacy non-HCI components.
- **Independent audits:** final-raster reconstruction, CLCD native area coverage sensitivity, equal weighting, leave-one-out and NPP comparison.

Do not tag v1.0.0 or call this code validated until a clean end-to-end test and DOI freeze are completed.


## Consistency update (2026-10-20)

- Added the Zenodo Version 2 data DOI: https://doi.org/10.5281/zenodo.23399406.
- Updated data-access documentation and CFF author metadata to match the current seven-author manuscript.
- Clarified that local pipeline folders are not necessarily the flat file listing shown in the Zenodo record.
- Aligned figure-generation CLI stages and output stems with manuscript Figures 6 and 7.
- No full raster workflow was executed as part of this documentation update; numerical validation status remains subject to the archived final audit outputs.


## Audit-evidence update (2026-10-20)

- Added the supplied final-raster audit report, audit flags, CLCD coverage sensitivity report and NPP plausibility summary under `docs/audits/`.
- Updated the manuscript's NPP strict common-support count to 6,364,569 to match the supplied independent NPP summary.
- Clarified that final-raster audit PASS does not certify every upstream source-processing decision and does not replace checking the Zenodo Version 2 file hashes.
- No ERA5-Land or target-grid Methods changes were made in this update.


## ERA5-Land source documentation update (2026-10-20)

- Explicitly cited the ERA5-Land monthly averaged product DOI: https://doi.org/10.24381/cds.68d2bb30.
- Clarified that 2-m air temperature and volumetric soil water layer 1 are the only ERA5-Land variables used in ERPI.
- Documented that the ERPI workflow consumes preprocessed annual stacks derived by weighted aggregation of monthly values; the main calculation script does not aggregate monthly files itself.
- The exact weighting basis and handling of incomplete months/years remain to be confirmed from upstream preprocessing records.


## ERA5-Land annual aggregation rule confirmed (2026-10-20)

- Specified calendar-day weighting for monthly means.
- Specified renormalization over remaining valid months when months are missing or invalid.
- Clarified that this aggregation occurs upstream and the main ERPI script consumes annual stacks.
- Retained the official ERA5-Land monthly averaged product DOI: https://doi.org/10.24381/cds.68d2bb30.
