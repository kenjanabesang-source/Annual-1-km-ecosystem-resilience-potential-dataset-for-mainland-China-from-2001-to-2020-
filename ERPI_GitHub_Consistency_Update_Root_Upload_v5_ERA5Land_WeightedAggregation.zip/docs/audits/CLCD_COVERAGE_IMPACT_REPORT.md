# CLCD native coverage: impact on corrected ERPI

**Candidate:** `<local corrected-candidate project directory>`

This sensitivity test changes spatial support only. It does not change the stored LCN values, NTL-corrected weights or ERPI values; no screening threshold is silently adopted.

Corrected candidate pixel-years audited: **181,800,565**.
Corrected candidate strict common pixels: **9,055,311**.

## Coverage screening scenarios

- Coverage ≥50%: remove 735 pixel-years (0.000404%); 735 removed cells touch an annual-support edge; strict common support 9,055,275 pixels (loss 36); max |annual mean shift| 0.000000422; max |fixed-support mean shift| 0.000000471.
- Coverage ≥90%: remove 13,241 pixel-years (0.007283%); 13,051 removed cells touch an annual-support edge; strict common support 9,054,685 pixels (loss 626); max |annual mean shift| 0.000004128; max |fixed-support mean shift| 0.000003557.
- Coverage ≥95%: remove 19,391 pixel-years (0.010666%); 19,066 removed cells touch an annual-support edge; strict common support 9,054,389 pixels (loss 922); max |annual mean shift| 0.000006379; max |fixed-support mean shift| 0.000005592.
- Coverage ≥99%: remove 32,306 pixel-years (0.017770%); 31,833 removed cells touch an annual-support edge; strict common support 9,053,782 pixels (loss 1,529); max |annual mean shift| 0.000009539; max |fixed-support mean shift| 0.000008147.

## Independent native-area overlap check

- Compared 7,637 valid sampled cells with exact native-area intersections; max |coverage difference| = 0.00000003; comparisons >0.005 = 0; unavailable full-grid coverage at sampled footprint cells = 0.

## Interpretation

- A full-cell source-area cutoff can exclude legitimate partially covered coastline/boundary cells. Do not treat 90% as a biological threshold or automatically discard these pixels.
- This is an exact support-screening comparison for the current candidate. If a screened product is to replace it, normalization and entropy weights must be reconsidered and a new version audited.
- The previous stratified exact native-area LCN reconstruction addresses arithmetic agreement only at sampled cells. It does not prove coverage adequacy in every low-coverage cell.

Outputs: `CLCD_coverage_impact_by_year.csv`, `CLCD_common_support_by_scenario.csv`, `CLCD_common_support_temporal_sensitivity.csv`, `CLCD_below90pct_locations.csv`, and the coverage/ and common-support GeoTIFFs.