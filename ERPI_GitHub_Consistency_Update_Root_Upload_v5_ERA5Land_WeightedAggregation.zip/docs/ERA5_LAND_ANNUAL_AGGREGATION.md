# ERA5-Land annual aggregation rule

## Source
ERA5-Land monthly averaged data from 1950 to present, Copernicus Climate Change Service (C3S) Climate Data Store.
DOI: https://doi.org/10.24381/cds.68d2bb30

## Variables used by ERPI
- 2-m air temperature
- Volumetric soil water layer 1

Other ERA5-Land variables are not inputs to ERPI.

## Annual aggregation
The monthly mean for each month is weighted by the number of calendar days in that month. Missing or invalid months are omitted, and the weights are renormalized over the remaining valid months.

For a year with valid months M_y, the annual value is:

X_y = sum(d_m * X_m) / sum(d_m), for m in M_y,

where X_m is the monthly mean and d_m is the number of calendar days in month m. The same rule is applied separately to each variable and grid cell using that cell's valid monthly observations.

## Workflow boundary
This aggregation was completed upstream before the annual GeoTIFF stacks entered the main ERPI calculation. The main ERPI script reads annual stacks and does not recompute monthly-to-annual values.
