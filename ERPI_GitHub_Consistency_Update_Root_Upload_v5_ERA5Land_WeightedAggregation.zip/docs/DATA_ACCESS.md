# Data access / files to publish

**Data status: public Zenodo Version 2 record available.** Data DOI: https://doi.org/10.5281/zenodo.23399406. Code repository: https://github.com/kenjanabesang-source/Annual-1-km-ecosystem-resilience-potential-dataset-for-mainland-China-from-2001-to-2020-.

## Input data (provider downloads, not hosted here)
- MODIS/Terra monthly vegetation indices (MOD13A3.061-derived annual files)
- CLCD v1 annual land cover
- PANDA-China nighttime lights
- ERA5-Land monthly averaged product, C3S Climate Data Store, DOI: https://doi.org/10.24381/cds.68d2bb30; the ERPI workflow uses 2-m air temperature and volumetric soil water layer 1. The 2000–2025 annual stacks are preprocessed derivatives created by weighted aggregation of monthly values; the ERPI script then extracts 2001–2020.
- MODIS MOD17A3HGF.061 NPP (independent context comparison only)

Consult the manuscript References for formal dataset citations and provider access instructions. The local annual rasters used here may be derived / transformed versions requiring separate provenance documentation.

## Corrected outputs to archive externally
- `ERI/ERI_2001.tif` ... `ERI/ERI_2020.tif`
- `indicators/{VCI,LCN,HCI,TSI,MSI}_<year>.tif`
- baseline layers and corrected `NTL_pooled_quantiles.json`
- `entropy_weights_fixed_2001_2020.csv`
- strict common-support masks and full technical QA records
- complete metadata/manifest, CRS, file hashes, data dictionary, methods README, license and version information

## Fill before submission
- Public data record (Version 2): https://doi.org/10.5281/zenodo.23399406
- Public code repository: https://github.com/kenjanabesang-source/Annual-1-km-ecosystem-resilience-potential-dataset-for-mainland-China-from-2001-to-2020-
- Separate software archive DOI: **not provided**; do not cite the data DOI as a code DOI.
- Final data and code reuse permissions: confirm all third-party data and source-code licensing terms.
- Exact third-party data versions, annual aggregation procedure and dependencies: verify from source metadata.
- Full numerical reproduction: the code package's static checks are not a substitute for running the full workflow and preserving the audit outputs.

GitHub is a code host; large GeoTIFFs should be deposited in a suitable public data repository with stable DOI and accessible review links.


## ERA5-Land monthly source and annual aggregation

Source product: ERA5-Land monthly averaged data from 1950 to present, Copernicus Climate Change Service (C3S) Climate Data Store (CDS), DOI: https://doi.org/10.24381/cds.68d2bb30.

Variables used by ERPI: 2-m air temperature and volumetric soil water layer 1 only. The annual input stacks supplied to the main ERPI workflow were produced upstream from monthly means using calendar-day weighting. If one or more months were missing or invalid, the annual value was calculated from the remaining valid months and the weights were renormalized over those months. The main ERPI script reads the preprocessed annual stacks and does not perform this monthly-to-annual aggregation itself.
