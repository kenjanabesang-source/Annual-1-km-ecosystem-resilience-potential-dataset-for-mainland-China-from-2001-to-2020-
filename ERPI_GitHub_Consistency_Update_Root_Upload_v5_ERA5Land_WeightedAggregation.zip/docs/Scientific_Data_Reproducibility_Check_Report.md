# Scientific Data — ERPI code reproducibility check

**Assessment date:** 2026-10-14  
**Release state:** *Public code repository linked to Zenodo Version 2 data; full end-to-end numerical reproduction is not verified by the static package checks documented here*.

## 1. Source-code recovery and packaging

- Nine relevant source Python files were retrieved from user-supplied materials and preserved in `archive/original_sources/`.
- Nine active, cross-platform copies live under `scripts/`. The exact differences are logged in `docs/PORTABILITY_PATCHES.diff`.
- Path defaults now use `ERPI_DATA_ROOT` and `ERPI_PRODUCT_ROOT`. The technical sensitivity and NPP comparison copies target the NTL-corrected dataset by default.
- An explicit `run_pipeline.py` stage dispatcher and a read-only `scripts/preflight_inventory.py` help verify local paths and run order.
- All 20 Python source files (9 original + 9 active + 2 utility scripts) passed static parsing/compilation. Dispatcher and preflight help commands returned successfully.

**Verification scope:** No original remote-sensing inputs or final GeoTIFF outputs were available for execution here. These checks are **not evidence that raster values, published weights, 20-year support masks or Figures 1–7 were reproduced**.

## 2. Code–manuscript correspondence

`docs/CODE_PAPER_MAP.md` and the accompanying workbook cover 16 links between manuscript sections, code functions and intended outputs. Main functions are found in the submitted source scripts, including upstream VCI/LCN/TSI/MSI, corrected NTL/HCI, pooled entropy weights, ERPI, NPP comparison, sensitivity analysis, and QA.

## 3. Issues to resolve before public submission

| Priority | Finding | Required follow-up |
|---|---|---|
| RESOLVED (access only) | Public data DOI now exists: https://doi.org/10.5281/zenodo.23399406 | Verify the complete Zenodo Version 2 inventory against Table 3 and preserve a release manifest |
| BLOCKER | End-to-end numerical reproduction not run here | Run on the original data and match every manuscript metric |
| HIGH | Core original workflow contains historical NTL fill handling | Clearly designate the NTL-corrected candidate as published product |
| HIGH | Corrected workflow reuses four archived component series | Preserve/reproduce legacy upstream intermediate generation and document provenance |
| HIGH | Legacy technical code can reuse preexisting `technical_validation/common_valid_mask_2001_2020.tif` | Back up and regenerate this derived file when changing product version |
| RESOLVED IN CODE NAMING | Manuscript uses Figures 6 and 7; active figure script output stems and CLI stages now use Fig6/Fig7 and `fig6`/`fig7` | Run the figure stage on the corrected product and confirm the generated panels visually match the manuscript captions |
| HIGH | Annual NDVI inputs are already aggregated | Publish the upstream annual-composite recipe and exact source lineage, if not already archived |
| HIGH | Release license not approved by all rights holders | Confirm MIT license for code and separate input-data rights |
| MEDIUM | No separate software DOI or tagged code release is available; CFF author list now matches the seven-author manuscript | Create a versioned software archive only after the final data/code audit; do not use the data DOI as a code DOI |
| MEDIUM | Generic conda dependency constraints rather than a tested lockfile | Export environment from the successful full rerun |
| MEDIUM | Figure 1 requires verified boundary/cartographic sources | Verify all vector licenses and provenance |

## 4. Manuscript values that require rerun verification

The manuscript reports the following, used only as **targets for comparison**, not measurements verified in this session:

- Valid pixel-years: **181,800,565**.
- Strict 20-year common support: **9,055,311** cells.
- Fixed weights (rounded): **VCI 0.404919; LCN 0.278581; HCI 0.155397; TSI 0.076801; MSI 0.084303**.
- Independent ERPI reconstruction: **zero mask mismatches** and maximum absolute error **2.98e-08**.

If rerun values differ, reconcile the code, source-data versions, masks and manuscript before public release. Do not silently overwrite prior research outputs.

## 5. Recommended publication sequence

1. Archive unmodified source scripts and original data/version records.
2. Rebuild or verify original upstream component files in an isolated folder.
3. Verify pre-warp `-32768` fill masking and build the corrected candidate.
4. Run independent source and final-raster audits, then rerun sensitivity/NPP outputs from corrected data.
5. Compare corrected outputs, figure labels and all manuscript values.
6. Record platform, package versions, manifests, hashes, and third-party file provenance.
7. The data archive is deposited at https://doi.org/10.5281/zenodo.23399406; verify its complete file inventory. The code repository is public, but no separate software DOI has been supplied.
8. Obtain license/author approvals and publish a tagged release only after all checks pass.

**Current decision: the code is publicly accessible and the dataset has a Version 2 Zenodo DOI, but this package's static checks alone do not verify the manuscript's numerical audit claims. Preserve the final audit outputs and reconcile the status in method_config_NTL_corrected.json before submission.**
