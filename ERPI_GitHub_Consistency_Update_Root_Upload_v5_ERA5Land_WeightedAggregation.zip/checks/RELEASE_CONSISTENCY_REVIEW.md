# Release consistency review — ERPI Version 2

Review update: 2026-10-20

## Evidence now supplied
- `docs/audits/ERPI_FINAL_RASTER_AUDIT_REPORT.md` reports **PASS**, with no critical or review-level findings, for the corrected PANDA-China NTL candidate.
- The report scanned 20/20 annual rasters, counted 181,800,565 valid pixel-years, found zero validity-mask mismatches, and reported maximum pixelwise reconstruction difference 2.98e-08.
- `docs/audits/10_ERPI_audit_flags.csv` contains one `INFO` flag: final-raster audit does not verify all upstream source-processing decisions.
- `docs/audits/CLCD_COVERAGE_IMPACT_REPORT.md` documents the CLCD native-area coverage sensitivity and cautions against treating coverage cutoffs as biological thresholds.
- `docs/audits/NPP_only_validation_summary.txt` reports the strict common ERPI+NPP support as 6,364,569 pixels.

## Still required before declaring the release fully verified
1. Confirm that the audited candidate's manifest and raster hashes correspond exactly to the GeoTIFFs deposited in Zenodo Version 2: https://doi.org/10.5281/zenodo.23399406.
2. Compare the complete Zenodo Version 2 file inventory against the manuscript's Data Records/Table 3.
3. Keep the source-level scope limitation explicit: final-raster PASS does not by itself certify every upstream input processing choice. The CLCD sensitivity analysis is available, but no arbitrary coverage threshold is imposed.
4. If the configuration file `method_config_NTL_corrected.json` is included in the public release, update its status only after confirming the audited candidate and deposited version are identical. Do not silently overwrite historical configuration records.

## Manuscript correction
The NPP validation report gives **6,364,569** strict common ERPI+NPP pixels. The manuscript had a conflicting value (8,885,125); the manuscript has now been corrected to match the supplied report.

## Scope note
ERA5-Land source/aggregation details and the target-grid Methods subsection were intentionally not modified in this update, per author instruction.


## ERA5-Land documentation update

- Source product: ERA5-Land monthly averaged data, C3S CDS, DOI https://doi.org/10.24381/cds.68d2bb30.
- Variables used in ERPI: 2-m air temperature and volumetric soil water layer 1 only.
- Annual input stacks are derived by weighted aggregation of monthly values before the main ERPI calculation; the main script reads annual bands 2001–2020 (bands 2–21 of 2000–2025 stacks).
- Exact weighting basis and missing-month policy are not established by the main ERPI script and need to be confirmed from upstream preprocessing documentation.

### ERA5-Land aggregation rule confirmed by the author

The annualization uses calendar-day weights for monthly means. Missing or invalid months are excluded and weights are renormalized over the remaining valid months. The main ERPI script consumes annual stacks; this aggregation occurs upstream. Source DOI: https://doi.org/10.24381/cds.68d2bb30.
